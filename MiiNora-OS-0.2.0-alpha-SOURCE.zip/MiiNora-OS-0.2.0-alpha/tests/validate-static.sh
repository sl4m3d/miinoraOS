#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
bash -n "$ROOT/os/build-rootfs.sh"
bash -n "$ROOT/os/scripts/package-3ds-boot-assets.sh"
bash -n "$ROOT/os/install-on-linux-host.sh"
sh -n "$ROOT/os/rootfs-overlay/usr/lib/miinora/first-boot-setup.sh"
sh -n "$ROOT/os/rootfs-overlay/etc/init.d/miinora-first-boot"
python3 -m py_compile "$ROOT/scripts/generate-assets.py"
python3 "$ROOT/scripts/generate-assets.py"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys, wave
from PIL import Image
root = Path(sys.argv[1])
assets = root / "installer/assets"
assert Image.open(assets / "icon.png").size == (48, 48)
assert Image.open(assets / "banner.png").size == (256, 128)
with wave.open(str(assets / "banner.wav")) as audio:
    assert audio.getframerate() == 22050
    assert audio.getnchannels() == 1
    assert audio.getsampwidth() == 2
assert (root / "installer/source/main.c").stat().st_size > 10000
assert "httpcGetResponseHeader" in (root / "installer/source/main.c").read_text()
assert "32u * 1024u" in (root / "installer/source/main.c").read_text()
assert (root / "os/rootfs-overlay/usr/lib/miinora/first-boot-setup.sh").is_file()
print("MiiNora static validation passed.")
PY
