# Third-party components and licenses

MiiNora's own installer and setup scripts are distributed under the repository's MIT license. The OS package also contains separately licensed upstream Nintendo 3DS Linux components:

- Linux kernel for Nintendo 3DS: GPL-2.0; upstream sources: https://github.com/linux-3ds/linux and the current 3DS-Linux kernel source link at https://3dslinux.org/.
- FIRM Linux Loader: GPL-2.0; source: https://github.com/linux-3ds/firm_linux_loader.
- ARM9 Linux firmware helper: GPL-2.0; source: https://github.com/linux-3ds/arm9linuxfw.
- Debian Bookworm packages: retain package copyright and license metadata inside the Debian root filesystem.

The release package records the upstream download URLs for the binary boot assets and kernel modules. Consult each upstream project's license and source repository when redistributing or modifying those components.
