#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

#define APP_VERSION "0.2.0-alpha"
#define PACKAGE_URL "https://github.com/sl4m3d/miinoraOS/releases/download/v0.2.0-alpha/MiiNora-OS-Package.tar.gz"
#define ROOT_DIR "sdmc:/MiiNora"
#define CONFIG_DIR ROOT_DIR "/config"
#define DOWNLOAD_DIR ROOT_DIR "/downloads"
#define PACKAGE_FILE DOWNLOAD_DIR "/MiiNora-OS-Package.tar.gz"
#define PACKAGE_TEMP DOWNLOAD_DIR "/MiiNora-OS-Package.tar.gz.part"
#define PACKAGE_BACKUP DOWNLOAD_DIR "/MiiNora-OS-Package.tar.gz.bak"
#define SETUP_FILE CONFIG_DIR "/installer-setup.ini"
#define MAX_PACKAGE_SIZE (768u * 1024u * 1024u)
#define DOWNLOAD_CHUNK (32u * 1024u)

typedef enum { PAGE_HOME = 0, PAGE_SETUP, PAGE_DOWNLOAD, PAGE_RESULT, PAGE_SETTINGS, PAGE_ABOUT, PAGE_FILES } Page;
static PrintConsole *topConsole;
static PrintConsole *bottomConsole;
static Page currentPage = PAGE_HOME;
static int selectedItem;
static int resultCode;
static bool sdReady;
static bool firstRun;
static bool confirmDownloads = true;
static bool touchHints = true;
static int timezoneIndex;
static unsigned int downloadPercent;
static char statusText[112] = "Ready";
static const char *timezones[] = {"UTC", "Europe/Berlin", "Europe/London", "America/New_York", "Asia/Tokyo"};
#define TIMEZONE_COUNT ((int)(sizeof(timezones) / sizeof(timezones[0])))
static const char *menuItems[] = {"Download OS package", "Prepare SD folders", "Settings", "About MiiNora", "Files", "Exit installer"};
#define MENU_COUNT ((int)(sizeof(menuItems) / sizeof(menuItems[0])))

static void safeMkdir(const char *path)
{
    if (mkdir(path, 0777) != 0 && errno != EEXIST)
        snprintf(statusText, sizeof(statusText), "Cannot create folder: %.70s", path);
}
static void ensureDirectories(void)
{
    if (!sdReady) return;
    safeMkdir(ROOT_DIR); safeMkdir(CONFIG_DIR); safeMkdir(DOWNLOAD_DIR);
    safeMkdir(ROOT_DIR "/system"); safeMkdir(ROOT_DIR "/backups"); safeMkdir(ROOT_DIR "/logs");
}
static bool setupExists(void)
{
    struct stat st;
    return stat(SETUP_FILE, &st) == 0 && st.st_size > 0;
}
static void saveSetup(void)
{
    FILE *f = fopen(SETUP_FILE ".tmp", "w");
    if (!f) { snprintf(statusText, sizeof(statusText), "Could not save setup preferences."); return; }
    fprintf(f, "language=en-US\ntimezone=%s\nconfirm_downloads=%s\ntouch_hints=%s\n",
            timezones[timezoneIndex], confirmDownloads ? "true" : "false", touchHints ? "true" : "false");
    if (fclose(f) != 0 || rename(SETUP_FILE ".tmp", SETUP_FILE) != 0) {
        remove(SETUP_FILE ".tmp"); snprintf(statusText, sizeof(statusText), "Could not finalize setup preferences."); return;
    }
    snprintf(statusText, sizeof(statusText), "Setup preferences saved.");
}
static void loadSetup(void)
{
    FILE *f = fopen(SETUP_FILE, "r");
    if (!f) return;
    char line[128];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "timezone=", 9) == 0) {
            line[strcspn(line, "\r\n")] = '\0';
            for (int i = 0; i < TIMEZONE_COUNT; i++) if (strcmp(line + 9, timezones[i]) == 0) timezoneIndex = i;
        } else if (strncmp(line, "confirm_downloads=", 18) == 0) confirmDownloads = strstr(line, "true") != NULL;
        else if (strncmp(line, "touch_hints=", 12) == 0) touchHints = strstr(line, "true") != NULL;
    }
    fclose(f);
}
static void flushFrame(void)
{
    gspWaitForVBlank(); gfxFlushBuffers(); gfxSwapBuffers();
}
static void playIntroAnimation(void)
{
    static const char *aurora[] = {
        "          .             *              ",
        "       .      .    *       .            ",
        "     .   ~~~      ~~~   .                ",
        "   .   ~~  *  ~~  *  ~~    .             ",
        "      ~~   M I I N O R A   ~~             ",
        "        ~~~    *    ~~~                  ",
        "             .     .                     "
    };
    for (int frame = 0; frame < 72 && aptMainLoop(); frame++) {
        consoleSelect(topConsole); consoleClear(); printf("\n\n\n");
        for (int i = 0; i < 7; i++) printf("%*s%s\n", (frame + i) % 3, "", aurora[i]);
        printf("\n             SYSTEM INSTALLER\n\n        Initialising MiiNora services\n\n        [");
        int filled = (frame + 1) * 20 / 72;
        for (int i = 0; i < 20; i++) putchar(i < filled ? '#' : '-');
        printf("] %d%%\n", (frame + 1) * 100 / 72);
        consoleSelect(bottomConsole); consoleClear();
        printf("MiiNora Setup\n\nA calm, lightweight Linux\nenvironment for Nintendo 3DS.\n\nPlease wait...\n");
        flushFrame();
    }
}
static void drawProgress(unsigned int percent)
{
    if (percent > 100) percent = 100;
    printf("\n[");
    for (unsigned int i = 0; i < 20; i++) putchar(i < percent / 5 ? '#' : '-');
    printf("] %u%%\n", percent);
}
static void drawFrame(void)
{
    consoleSelect(topConsole); consoleClear();
    printf("MiiNora OS | %s\nOLD 3DS / CTR | Installer\n----------------------------------------\n\n", APP_VERSION);
    switch (currentPage) {
    case PAGE_HOME:
        printf("Welcome to MiiNora\n\nA Debian-based Linux system for the\nNintendo 3DS.\n\nSelect an action on the lower screen.\n\nStatus: %s\n\nInstaller and Linux OS are separate.\n", statusText);
        break;
    case PAGE_SETUP:
        printf("First-use installer guide\n\nInterface language: English\nUse LEFT / RIGHT to choose timezone.\n\nTime zone: %s\n\nA: Save and continue\nB: Cancel\n", timezones[timezoneIndex]);
        break;
    case PAGE_DOWNLOAD:
        printf("Download MiiNora OS package\n\nThe package is downloaded in chunks\nto avoid reserving the full file in RAM.\n\nDestination:\nSD:/MiiNora/downloads/\nStatus: %s\n", statusText);
        drawProgress(downloadPercent);
        printf("\nA: Start download    B: Cancel\n");
        break;
    case PAGE_RESULT:
        printf("Operation result\n\n%s\n\n", statusText);
        if (resultCode == 0) printf("Saved package:\n%s\n", PACKAGE_FILE);
        printf("A/B: Return to menu\n");
        break;
    case PAGE_SETTINGS:
        printf("Installer settings\n\n%c Confirm downloads: %s\n%c Touch hints: %s\n\nUP/DOWN select, A toggle.\n",
               selectedItem == 0 ? '>' : ' ', confirmDownloads ? "ON" : "OFF",
               selectedItem == 1 ? '>' : ' ', touchHints ? "ON" : "OFF");
        break;
    case PAGE_ABOUT:
        printf("About MiiNora\n\nVersion: %s\nTarget: Nintendo 3DS Old model\nUserspace: Debian Bookworm armel\nBoot: Luma3DS -> FIRM Linux Loader\n\nNo Raspberry Pi kernel or drivers are\nused as 3DS hardware support.\n", APP_VERSION);
        break;
    case PAGE_FILES: {
        printf("MiiNora Files\n\nSD:/MiiNora/downloads/\n\n");
        if (!sdReady) { printf("SD card filesystem unavailable.\n"); break; }
        DIR *dir = opendir(DOWNLOAD_DIR);
        if (!dir) { printf("Folder is empty or unavailable.\n"); break; }
        struct dirent *entry; int shown = 0;
        while ((entry = readdir(dir)) != NULL && shown < 10) {
            if (entry->d_name[0] == '.') continue;
            printf("%.34s\n", entry->d_name); shown++;
        }
        if (shown == 0) printf("No files yet.\n");
        closedir(dir); break;
    }
    }
    printf("\n----------------------------------------\nB: Back   START: Exit\n");
}
static void drawTouchPanel(void)
{
    consoleSelect(bottomConsole); consoleClear();
    printf("MiiNora Control Center\n------------------------------\n\n");
    if (currentPage == PAGE_HOME) {
        for (int i = 0; i < MENU_COUNT; i++) printf("%c %s\n", selectedItem == i ? '>' : ' ', menuItems[i]);
        if (touchHints) printf("\nTap a row or use UP/DOWN + A.\n");
    } else if (currentPage == PAGE_SETTINGS) {
        printf("%c Confirm downloads\n%c Touch hints\n", selectedItem == 0 ? '>' : ' ', selectedItem == 1 ? '>' : ' ');
    } else if (currentPage == PAGE_SETUP) {
        printf("FIRST-USE SETUP\n\nLanguage: English\nTime zone: %s\nLEFT/RIGHT: Change zone\nA: Save preferences\n", timezones[timezoneIndex]);
    } else {
        printf("Touch controls\n\nA: Select / continue\nB: Back\nSTART: Exit installer\n");
    }
}
static Result openPackageConnection(httpcContext *context, u32 *responseCode)
{
    char url[4096];
    snprintf(url, sizeof(url), "%s", PACKAGE_URL);
    for (int redirect = 0; redirect <= 5; redirect++) {
        Result result = httpcOpenContext(context, HTTPC_METHOD_GET, url, 0);
        if (R_FAILED(result)) return result;
        httpcAddRequestHeaderField(context, "User-Agent", "MiiNora-Installer/0.2.0");
        httpcAddRequestHeaderField(context, "Accept", "application/octet-stream");
        httpcAddDefaultCert(context, SSLC_DefaultRootCert_DigiCert_EV);
        httpcAddDefaultCert(context, SSLC_DefaultRootCert_USERTrust);
        httpcAddDefaultCert(context, SSLC_DefaultRootCert_COMODO);
        httpcAddDefaultCert(context, SSLC_DefaultRootCert_CyberTrust);
        result = httpcBeginRequest(context);
        if (R_FAILED(result)) { httpcCancelConnection(context); httpcCloseContext(context); return result; }
        result = httpcGetResponseStatusCodeTimeout(context, responseCode, 30000000000ULL);
        if (R_FAILED(result)) { httpcCancelConnection(context); httpcCloseContext(context); return result; }
        if (*responseCode == 200) return 0;
        if (*responseCode != 301 && *responseCode != 302 && *responseCode != 303 &&
            *responseCode != 307 && *responseCode != 308) {
            httpcCancelConnection(context);
            httpcCloseContext(context);
            return -1;
        }
        if (redirect == 5) { httpcCancelConnection(context); httpcCloseContext(context); return -1; }
        char location[4096] = {0};
        result = httpcGetResponseHeader(context, "Location", location, sizeof(location));
        httpcCancelConnection(context);
        httpcCloseContext(context);
        if (R_FAILED(result) || strncmp(location, "https://", 8) != 0) return -1;
        snprintf(url, sizeof(url), "%s", location);
    }
    return -1;
}

static int downloadPackage(void)
{
    httpcContext context; Result result; u32 responseCode = 0, received = 0, contentSize = 0;
    u8 *buffer = NULL; FILE *file = NULL; bool httpcReady = false, contextOpen = false; int outcome = -1;
    if (!sdReady) { snprintf(statusText, sizeof(statusText), "SD card filesystem is unavailable."); return -1; }
    buffer = (u8 *)malloc(DOWNLOAD_CHUNK);
    if (!buffer) { snprintf(statusText, sizeof(statusText), "Not enough memory for download buffer."); return -1; }
    snprintf(statusText, sizeof(statusText), "Starting network service..."); downloadPercent = 0; drawFrame();
    result = httpcInit(0);
    if (R_FAILED(result)) { snprintf(statusText, sizeof(statusText), "Network service unavailable (0x%08lX).", (unsigned long)result); goto cleanup; }
    httpcReady = true;
    result = openPackageConnection(&context, &responseCode);
    if (R_FAILED(result)) {
        snprintf(statusText, sizeof(statusText), "HTTPS download failed (HTTP %lu, result 0x%08lX).", (unsigned long)responseCode, (unsigned long)result);
        goto cleanup;
    }
    contextOpen = true;
    result = httpcGetDownloadSizeState(&context, &received, &contentSize);
    if (R_FAILED(result) || contentSize == 0 || contentSize > MAX_PACKAGE_SIZE) { snprintf(statusText, sizeof(statusText), "Invalid package size or package exceeds 768 MiB."); goto cleanup; }
    ensureDirectories(); remove(PACKAGE_TEMP);
    file = fopen(PACKAGE_TEMP, "wb");
    if (!file) { snprintf(statusText, sizeof(statusText), "Could not create temporary package file."); goto cleanup; }
    u32 total = 0;
    while (total < contentSize) {
        u32 requestSize = contentSize - total; if (requestSize > DOWNLOAD_CHUNK) requestSize = DOWNLOAD_CHUNK;
        u32 chunkReceived = 0;
        result = httpcDownloadData(&context, buffer, requestSize, &chunkReceived);
        if (R_FAILED(result) || chunkReceived == 0 || chunkReceived > requestSize) {
            snprintf(statusText, sizeof(statusText), "Download stopped at %lu of %lu bytes.", (unsigned long)total, (unsigned long)contentSize); goto cleanup;
        }
        if (fwrite(buffer, 1, chunkReceived, file) != chunkReceived) { snprintf(statusText, sizeof(statusText), "SD card write failed."); goto cleanup; }
        total += chunkReceived; downloadPercent = (unsigned int)(((unsigned long long)total * 100u) / contentSize);
        snprintf(statusText, sizeof(statusText), "Downloading package: %lu / %lu bytes.", (unsigned long)total, (unsigned long)contentSize);
        drawFrame(); drawTouchPanel(); flushFrame();
    }
    if (fflush(file) != 0) { snprintf(statusText, sizeof(statusText), "Could not flush package data to SD card."); goto cleanup; }
    if (fclose(file) != 0) { file = NULL; snprintf(statusText, sizeof(statusText), "Could not close package file cleanly."); goto cleanup; }
    file = NULL;
    remove(PACKAGE_BACKUP);
    if (rename(PACKAGE_FILE, PACKAGE_BACKUP) != 0 && errno != ENOENT) { snprintf(statusText, sizeof(statusText), "Could not preserve the previous package."); goto cleanup; }
    if (rename(PACKAGE_TEMP, PACKAGE_FILE) != 0) {
        (void)rename(PACKAGE_BACKUP, PACKAGE_FILE);
        snprintf(statusText, sizeof(statusText), "Could not finalize downloaded package."); goto cleanup;
    }
    remove(PACKAGE_BACKUP);
    downloadPercent = 100;
    snprintf(statusText, sizeof(statusText), "Package downloaded successfully. Extraction is a separate step.");
    outcome = 0;
cleanup:
    if (file) fclose(file);
    if (outcome != 0) remove(PACKAGE_TEMP);
    if (contextOpen) { if (outcome != 0) httpcCancelConnection(&context); httpcCloseContext(&context); }
    if (httpcReady) httpcExit();
    free(buffer); return outcome;
}
static void runSetupPage(void)
{
    currentPage = PAGE_SETUP; selectedItem = 0;
    drawFrame(); drawTouchPanel(); flushFrame();
    while (aptMainLoop()) {
        hidScanInput(); u32 down = hidKeysDown();
        if (down & KEY_START) break;
        if (down & KEY_LEFT) timezoneIndex = (timezoneIndex + TIMEZONE_COUNT - 1) % TIMEZONE_COUNT;
        if (down & KEY_RIGHT) timezoneIndex = (timezoneIndex + 1) % TIMEZONE_COUNT;
        if (down & KEY_A) { saveSetup(); firstRun = !setupExists(); break; }
        if (down & KEY_B) break;
        drawFrame(); drawTouchPanel(); flushFrame();
    }
    currentPage = PAGE_HOME;
}
int main(int argc, char *argv[])
{
    (void)argc; (void)argv;
    gfxInitDefault(); topConsole = consoleInit(GFX_TOP, NULL); bottomConsole = consoleInit(GFX_BOTTOM, NULL);
    sdReady = R_SUCCEEDED(fsInit());
    playIntroAnimation();
    if (sdReady) { ensureDirectories(); firstRun = !setupExists(); loadSetup(); }
    else { firstRun = false; snprintf(statusText, sizeof(statusText), "SD card filesystem unavailable."); }
    if (firstRun) runSetupPage();

    bool exitApp = false;
    while (aptMainLoop() && !exitApp) {
        hidScanInput(); u32 down = hidKeysDown(); touchPosition touch; hidTouchRead(&touch);
        if (down & KEY_START) break;
        if (currentPage == PAGE_HOME) {
            if (down & KEY_DOWN) selectedItem = (selectedItem + 1) % MENU_COUNT;
            if (down & KEY_UP) selectedItem = (selectedItem + MENU_COUNT - 1) % MENU_COUNT;
            if (down & KEY_A) {
                switch (selectedItem) {
                case 0: downloadPercent = 0; if (confirmDownloads) currentPage = PAGE_DOWNLOAD; else { resultCode = downloadPackage(); currentPage = PAGE_RESULT; } break;
                case 1: ensureDirectories(); snprintf(statusText, sizeof(statusText), "MiiNora folders are ready on the SD card."); currentPage = PAGE_RESULT; resultCode = 1; break;
                case 2: currentPage = PAGE_SETTINGS; selectedItem = 0; break;
                case 3: currentPage = PAGE_ABOUT; break;
                case 4: currentPage = PAGE_FILES; break;
                case 5: exitApp = true; break;
                }
            }
            if (down & KEY_TOUCH) {
                int row = touch.py / 8 - 3;
                if (row >= 0 && row < MENU_COUNT) {
                    selectedItem = row;
                    if (row == 0) { downloadPercent = 0; if (confirmDownloads) currentPage = PAGE_DOWNLOAD; else { resultCode = downloadPackage(); currentPage = PAGE_RESULT; } }
                    else if (row == 1) { ensureDirectories(); snprintf(statusText, sizeof(statusText), "MiiNora folders are ready on the SD card."); currentPage = PAGE_RESULT; resultCode = 1; }
                    else if (row == 2) { currentPage = PAGE_SETTINGS; selectedItem = 0; }
                    else if (row == 3) currentPage = PAGE_ABOUT;
                    else if (row == 4) currentPage = PAGE_FILES;
                    else if (row == 5) exitApp = true;
                }
            }
        } else if (currentPage == PAGE_DOWNLOAD) {
            if (down & KEY_A) { resultCode = downloadPackage(); currentPage = PAGE_RESULT; }
            if (down & KEY_B) currentPage = PAGE_HOME;
        } else if (currentPage == PAGE_SETTINGS) {
            if (down & (KEY_UP | KEY_DOWN)) selectedItem = 1 - selectedItem;
            if (down & KEY_A) { if (selectedItem == 0) confirmDownloads = !confirmDownloads; else touchHints = !touchHints; saveSetup(); }
        } else if (down & (KEY_A | KEY_B)) currentPage = PAGE_HOME;
        drawFrame(); drawTouchPanel(); flushFrame();
    }
    if (sdReady) fsExit();
    gfxExit();
    return 0;
}
