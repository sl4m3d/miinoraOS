#!/usr/bin/env bash
set -euo pipefail
# Build Debian Bookworm armel userspace. 3DS kernel/DTB/modules are separate inputs.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/dist/rootfs}"
ARCH=armel
SUITE=bookworm
MIRROR=https://deb.debian.org/debian
[[ "$(id -u)" -eq 0 ]] || { echo 'Run as root.' >&2; exit 1; }
for tool in debootstrap qemu-arm-static update-binfmts; do command -v "$tool" >/dev/null || { echo "$tool is required." >&2; exit 1; }; done
update-binfmts --enable qemu-arm || true
mkdir -p "$OUT"
ROOTFS="$OUT/miinora-rootfs"
rm -rf "$ROOTFS" && mkdir -p "$ROOTFS"
debootstrap --arch="$ARCH" --foreign --variant=minbase "$SUITE" "$ROOTFS" "$MIRROR"
install -D "$(command -v qemu-arm-static)" "$ROOTFS/usr/bin/qemu-arm-static"
chroot "$ROOTFS" /debootstrap/debootstrap --second-stage
cat > "$ROOTFS/etc/apt/sources.list" <<APT
deb $MIRROR $SUITE main contrib non-free-firmware
deb $MIRROR $SUITE-updates main contrib non-free-firmware
deb http://security.debian.org/debian-security $SUITE-security main contrib non-free-firmware
APT
mount --bind /dev "$ROOTFS/dev"
mount -t proc proc "$ROOTFS/proc"
mount -t sysfs sysfs "$ROOTFS/sys"
cleanup() { umount -lf "$ROOTFS/sys" 2>/dev/null || true; umount -lf "$ROOTFS/proc" 2>/dev/null || true; umount -lf "$ROOTFS/dev" 2>/dev/null || true; }
trap cleanup EXIT
chroot "$ROOTFS" /usr/bin/qemu-arm-static /bin/sh -c '
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y --no-install-recommends \
    apt ca-certificates locales tzdata sysvinit-core sysv-rc \
    bash dash coreutils util-linux procps iproute2 iputils-ping \
    kmod mount e2fsprogs dosfstools net-tools nano less \
    python3-minimal openssh-client sudo passwd login fbset \
    wpasupplicant wireless-tools iw
  echo "en_US.UTF-8 UTF-8" > /etc/locale.gen
  locale-gen
  update-locale LANG=en_US.UTF-8
  echo miinora-3ds > /etc/hostname
  ln -sf /usr/share/zoneinfo/Etc/UTC /etc/localtime
  echo Etc/UTC > /etc/timezone
  apt-get clean
  rm -rf /var/lib/apt/lists/* /var/cache/apt/archives/*.deb
'
cp -a "$ROOT/os/rootfs-overlay/." "$ROOTFS/"
install -d "$ROOTFS/var/lib/miinora"
chroot "$ROOTFS" /usr/sbin/update-rc.d miinora-first-boot defaults 01
rm -f "$ROOTFS/usr/bin/qemu-arm-static"
mkdir -p "$OUT/package" && rm -rf "$OUT/package"/*
cp -a "$ROOTFS/." "$OUT/package/"
tar --sort=name --mtime='UTC 2024-01-01' --owner=0 --group=0 --numeric-owner \
  -C "$OUT/package" -czf "$OUT/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz" .
echo "RootFS created: $OUT/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz"
file "$OUT/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz"
du -h "$OUT/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz"
