# MiiNora hardware driver source of truth

MiiNora does **not** use a Raspberry Pi kernel or Raspberry Pi device drivers. It packages the Nintendo 3DS-specific kernel, device tree, ARM9 firmware, matching kernel modules and FIRM Linux Loader from the upstream 3DS-Linux downloads. The release workflow fails if required boot components or kernel modules are missing.

## Upstream documented support

The upstream project currently documents Old 3DS boot from Luma3DS, SD storage, upper-screen 400x240 framebuffer, a bottom-screen virtual keyboard, battery reporting, Circle Pad mouse movement, GPIO button input, accelerometer and Atheros AR6014 Wi-Fi. Sound is unsupported and powering off can panic. Source: https://3dslinux.org/.

## AR6014 firmware

The AR6014 driver requires console-specific Wi-Fi firmware. The upstream installation guide requires extracting it from the user's own console using GodMode9 and placing `fw-ar6014.bin` at:

`/usr/lib/firmware/ath6k/AR6014/hw1.0/fw-ar6014.bin`

MiiNora does not redistribute this device firmware. The host installer accepts a user-provided firmware file as its optional fourth argument. Without it, Wi-Fi is not ready and is explicitly marked missing.

## Dual-screen/touch limitation

The standard Linux framebuffer is documented for the upper display; lower-screen support is described as a virtual keyboard. That is not equivalent to a fully independent lower-screen framebuffer with general touch events for a custom desktop. MiiNora does not claim full dual-screen touch window management until implemented and tested on real Old 3DS hardware.

## Hardware validation boundary

CI validates file presence, architecture and packaging. It cannot prove that the kernel boots on the user's console or that touch, Wi-Fi, and shutdown work there. Those require real hardware testing and logs.
