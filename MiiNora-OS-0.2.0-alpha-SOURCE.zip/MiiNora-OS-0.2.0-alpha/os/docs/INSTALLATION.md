# MiiNora SD installation notes

1. Back up the complete 3DS SD card.
2. Prepare two partitions on a Linux host: FAT32 for Luma3DS and boot assets; ext4 for the Debian root filesystem. Do not format the existing Luma3DS partition.
3. Extract `MiiNora-OS-Package.tar.gz` on the host.
4. Mount both partitions, install `kmod` on the host (for `depmod`), and run:

   ```sh
   sudo ./os/install-on-linux-host.sh /mnt/3ds-fat32 /mnt/miinora-ext4 ./MiiNora-OS-Package [path/to/fw-ar6014.bin]
   ```

5. Eject safely, insert the card into the Old 3DS, and boot the FIRM Linux Loader payload from Luma3DS. The upstream current guide documents holding Y while powering on for its default Linux boot sequence.

The installer requires an actual FAT32 (`vfat`) boot partition and ext4 root partition. It allows only the standard `lost+found` directory on ext4. Existing boot files are backed up before replacement. Rootfs extraction is staged and rolled back on failure. No formatting or repartitioning is performed.

## Why the CIA is not a one-click ext4 installer yet

The native 3DS homebrew app accesses the SD through libctru; it does not provide an ext4 formatter/mounter. This project does not pretend the CIA can install Debian directly into ext4. It downloads the system package to FAT32; the host script performs the ext4 extraction. A true on-device installer needs a separately bootable installer environment with ext4 support and a proven non-destructive partition strategy.
