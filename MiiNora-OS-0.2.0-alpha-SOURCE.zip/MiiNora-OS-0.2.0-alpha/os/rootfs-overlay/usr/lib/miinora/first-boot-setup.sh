#!/bin/sh
set -eu
MARKER=/var/lib/miinora/setup-complete
[ -e "$MARKER" ] && exit 0
mkdir -p /var/lib/miinora /etc/miinora
clear || true
cat <<'BANNER'
========================================
             MiiNora OS
           First Boot Setup
========================================
This guide appears only once. You can
change these settings later in Settings.
BANNER

printf '\n1/5  Language\nThe initial MiiNora release uses English.\nPress ENTER to continue: '
read _continue || true

printf '\n2/5  Region and time zone\nEnter an IANA time zone (default Europe/Berlin): '
read TZ_NAME || TZ_NAME=Europe/Berlin
[ -n "${TZ_NAME:-}" ] || TZ_NAME=Europe/Berlin
case "$TZ_NAME" in *..*|/*|*[!A-Za-z0-9_+/-]*) TZ_NAME=Europe/Berlin ;; esac
if [ ! -f "/usr/share/zoneinfo/$TZ_NAME" ]; then
    echo "Unknown time zone. Using Europe/Berlin."
    TZ_NAME=Europe/Berlin
fi
echo "$TZ_NAME" > /etc/timezone
ln -sf "/usr/share/zoneinfo/$TZ_NAME" /etc/localtime

printf '\n3/5  Device name\nEnter a device name (default miinora-3ds): '
read HOSTNAME || HOSTNAME=miinora-3ds
HOSTNAME=${HOSTNAME:-miinora-3ds}
case "$HOSTNAME" in ""|*[!A-Za-z0-9-]*|-*) HOSTNAME=miinora-3ds ;; esac
printf '%s\n' "$HOSTNAME" > /etc/hostname
if grep -q '^127\.0\.1\.1' /etc/hosts 2>/dev/null; then
    sed -i "s/^127\.0\.1\.1.*/127.0.1.1\t$HOSTNAME/" /etc/hosts
else
    printf '127.0.1.1\t%s\n' "$HOSTNAME" >> /etc/hosts
fi

printf '\n4/5  Clock\nEnter local date and time as YYYY-MM-DD HH:MM:SS\n(leave blank to keep the current system clock): '
read CLOCK_VALUE || CLOCK_VALUE=
if [ -n "${CLOCK_VALUE:-}" ]; then
    if date -s "$CLOCK_VALUE" >/dev/null 2>&1; then
        if command -v hwclock >/dev/null 2>&1 && [ -e /dev/rtc ]; then hwclock --systohc 2>/dev/null || true; fi
        echo "Clock updated."
    else
        echo "Date/time format not accepted; keeping existing clock."
    fi
fi

printf '\n5/5  Account security\nSet a password for the root administrator account.\n'
passwd root
printf '\nCreate a normal user account now? [Y/n] '
read CREATE_USER || CREATE_USER=n
case "$CREATE_USER" in n|N|no|NO) ;; *)
    printf 'Username (default miinora): '
    read USERNAME || USERNAME=miinora
    USERNAME=${USERNAME:-miinora}
    case "$USERNAME" in ""|root|*[!a-z0-9_-]*) USERNAME=miinora ;; esac
    if ! id "$USERNAME" >/dev/null 2>&1; then useradd -m -s /bin/sh "$USERNAME"; fi
    if id "$USERNAME" >/dev/null 2>&1; then usermod -aG sudo "$USERNAME"; passwd "$USERNAME" || true; fi
    ;;
esac

printf '\nlanguage=en-US\ntimezone=%s\nhostname=%s\n' "$TZ_NAME" "$HOSTNAME" > /etc/miinora/system.conf
touch "$MARKER"
sync
printf '\nSetup complete. MiiNora is ready. Restart now? [y/N] '
read REBOOT_NOW || REBOOT_NOW=n
case "$REBOOT_NOW" in y|Y|yes|YES) sync; reboot || true ;; esac
exit 0
