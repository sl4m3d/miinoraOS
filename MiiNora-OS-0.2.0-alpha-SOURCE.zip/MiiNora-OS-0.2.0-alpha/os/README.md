# MiiNora Linux system

MiiNora targets the original Nintendo 3DS (ARMv6 / ARM11). It uses a Debian Bookworm `armel` userspace paired with the dedicated 3DS-Linux hardware kernel, device tree, ARM9 firmware, matching kernel modules and FIRM Linux Loader. Raspberry Pi OS and Raspberry Pi drivers are not used.

## Build target

- Userspace: Debian 12 Bookworm `armel` minimal root filesystem.
- Init: SysVinit.
- Package manager: APT / dpkg.
- Root filesystem: ext4; boot partition: FAT32.
- Hardware boot assets and kernel modules: upstream 3DS-Linux project.
- Launcher: `luma/payloads/firm_linux_loader.firm`.

Bookworm is selected because Debian 13/Trixie is the last armel release and armel is no longer supported as a regular new-installation architecture; Trixie's armel kernel packages support only specific Raspberry Pi models. They are not a substitute for the Old 3DS kernel. See https://www.debian.org/releases/trixie/release-notes/issues.en.html#last-release-for-armel.

## Build the root filesystem

On an Ubuntu/Debian x86_64 host:

```sh
sudo apt-get install debootstrap qemu-user-static binfmt-support
sudo update-binfmts --enable qemu-arm
sudo ./os/build-rootfs.sh
```

This creates `dist/rootfs/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz`. It creates the Debian userspace only; the upstream package script obtains the 3DS kernel, DTB, ARM9 firmware, loader and modules separately.

## Build and install package

GitHub Actions fetches the official 3DS-Linux SD files and matching kernel-module archive, validates required files and module presence, creates the Debian rootfs, then assembles `MiiNora-OS-Package.tar.gz`.

The native CIA can download the OS package to the SD FAT32 partition. It cannot create an ext4 partition or extract a Debian rootfs onto ext4 from the 3DS itself. The current safe installation flow therefore uses `os/install-on-linux-host.sh` after the SD card has a FAT32 boot partition and an empty ext4 root partition. The host script validates both mounted filesystems, refuses to overwrite an existing rootfs, stages extraction, and backs up existing boot files. It does not format or repartition the card.

## First boot

The SysVinit hook runs `/usr/lib/miinora/first-boot-setup.sh` exactly once. The English-language guide configures timezone, hostname, clock, root password and an optional normal user, then offers a restart.

## Hardware support status

See [HARDWARE-DRIVER-STATUS.md](docs/HARDWARE-DRIVER-STATUS.md). Console-specific AR6014 Wi-Fi firmware is not redistributed and must be imported by the owner. Upstream also documents unsupported sound and shutdown limitations. The full lower-screen touch desktop is not yet hardware-verified.
