#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT="${1:-$ROOT/dist/os-package}"
WORK="${RUNNER_TEMP:-/tmp}/miinora-3ds-boot-assets"
SD_URL="https://3dslinux.org/files/sd_files.tar.gz"
MODULES_URL="https://3dslinux.org/files/modules.tar"
rm -rf "$WORK" "$OUT"
mkdir -p "$WORK/unpacked" "$WORK/modules" "$OUT/fat32" "$OUT/rootfs" "$OUT/modules"
curl --fail --location --retry 4 --retry-all-errors --connect-timeout 20 "$SD_URL" -o "$WORK/sd_files.tar.gz"
curl --fail --location --retry 4 --retry-all-errors --connect-timeout 20 "$MODULES_URL" -o "$WORK/modules.tar"
while IFS= read -r member; do
  case "$member" in /*|../*|*/../*|*/..) echo "Unsafe path in upstream SD archive: $member" >&2; exit 1 ;; esac
done < <(tar -tzf "$WORK/sd_files.tar.gz")
while IFS= read -r member; do
  case "$member" in /*|../*|*/../*|*/..) echo "Unsafe path in upstream module archive: $member" >&2; exit 1 ;; esac
done < <(tar -tf "$WORK/modules.tar")
tar -xzf "$WORK/sd_files.tar.gz" -C "$WORK/unpacked"
tar -xf "$WORK/modules.tar" -C "$WORK/modules"
# Normalize the upstream module tree to /lib/modules inside the Debian rootfs.
MODULE_ROOT="$(find "$WORK/modules" -type d -path '*/lib/modules' -print -quit)"
if [[ -n "$MODULE_ROOT" ]]; then
  mkdir -p "$OUT/modules/lib/modules"
  cp -a "$MODULE_ROOT/." "$OUT/modules/lib/modules/"
else
  MODULES_DEP="$(find "$WORK/modules" -type f -name modules.dep -print -quit)"
  if [[ -z "$MODULES_DEP" ]]; then
    echo 'Upstream module archive has no lib/modules tree or modules.dep file.' >&2
    exit 1
  fi
  MODULE_VERSION_DIR="$(dirname "$MODULES_DEP")"
  mkdir -p "$OUT/modules/lib/modules/$(basename "$MODULE_VERSION_DIR")"
  cp -a "$MODULE_VERSION_DIR/." "$OUT/modules/lib/modules/$(basename "$MODULE_VERSION_DIR")/"
fi
tar --sort=name --owner=0 --group=0 --numeric-owner -C "$OUT/modules" -cf "$OUT/modules/3ds-modules.tar" lib/modules
# Preserve the upstream boot configuration and every file the loader expects.
cp -a "$WORK/unpacked/." "$OUT/fat32/"
find_one() { find "$WORK/unpacked" -type f -iname "$1" -print -quit; }
ZIMAGE="$(find_one zImage)"
DTB="$(find "$WORK/unpacked" -type f -iname '*nintendo3ds*ctr*.dtb' -print -quit)"
ARM9FW="$(find_one arm9linuxfw.bin)"
LOADER="$(find_one firm_linux_loader.firm)"
for name in ZIMAGE DTB ARM9FW LOADER; do
  [[ -n "${!name}" ]] || { echo "Missing required upstream 3DS component: $name" >&2; find "$WORK/unpacked" -type f -print >&2; exit 1; }
done
tar -tf "$OUT/modules/3ds-modules.tar" | grep -Eq '(^|/)lib/modules/.+\.ko(\.xz|\.gz)?$' || { echo 'Upstream modules archive contains no kernel modules.' >&2; exit 1; }
install -D -m 0644 "$ZIMAGE" "$OUT/fat32/linux/zImage"
install -D -m 0644 "$DTB" "$OUT/fat32/linux/nintendo3ds_ctr.dtb"
install -D -m 0644 "$ARM9FW" "$OUT/fat32/linux/arm9linuxfw.bin"
install -D -m 0644 "$LOADER" "$OUT/fat32/luma/payloads/firm_linux_loader.firm"
cat > "$OUT/BOOT-ASSET-SOURCE.txt" <<SRC
3DS boot assets: $SD_URL
3DS kernel modules: $MODULES_URL
These are Nintendo 3DS-specific components, not Raspberry Pi binaries.
Console-specific AR6014 firmware is not redistributed. Import the user's own
fw-ar6014.bin into /usr/lib/firmware/ath6k/AR6014/hw1.0/fw-ar6014.bin.
SRC
for f in "$OUT/fat32/linux/zImage" "$OUT/fat32/linux/nintendo3ds_ctr.dtb" "$OUT/fat32/linux/arm9linuxfw.bin" "$OUT/fat32/luma/payloads/firm_linux_loader.firm" "$OUT/modules/3ds-modules.tar"; do test -s "$f"; done
