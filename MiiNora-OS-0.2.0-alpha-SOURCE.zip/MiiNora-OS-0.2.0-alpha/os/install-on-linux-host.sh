#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 3 || $# -gt 4 ]]; then
  echo "Usage: sudo $0 <fat32-mount> <ext4-rootfs-mount> <extracted-package-dir> [fw-ar6014.bin]" >&2
  exit 2
fi
FAT_MOUNT="$(realpath "$1")"
ROOT_MOUNT="$(realpath "$2")"
PACKAGE="$(realpath "$3")"
WIFI_FW="${4:-}"
[[ "$(id -u)" -eq 0 ]] || { echo 'Run this installer as root.' >&2; exit 1; }
mountpoint -q "$FAT_MOUNT" || { echo "FAT32 mount is not mounted: $FAT_MOUNT" >&2; exit 1; }
mountpoint -q "$ROOT_MOUNT" || { echo "ext4 mount is not mounted: $ROOT_MOUNT" >&2; exit 1; }
FAT_TYPE="$(findmnt -n -o FSTYPE --target "$FAT_MOUNT")"
ROOT_TYPE="$(findmnt -n -o FSTYPE --target "$ROOT_MOUNT")"
[[ "$FAT_TYPE" == vfat ]] || { echo "Expected FAT32 boot partition (vfat), got $FAT_TYPE" >&2; exit 1; }
[[ "$ROOT_TYPE" == ext4 ]] || { echo "Expected ext4 rootfs partition, got $ROOT_TYPE" >&2; exit 1; }
if [[ -n "$WIFI_FW" && ! -s "$WIFI_FW" ]]; then echo "Wi-Fi firmware does not exist: $WIFI_FW" >&2; exit 1; fi
for rel in linux/zImage linux/nintendo3ds_ctr.dtb linux/arm9linuxfw.bin luma/payloads/firm_linux_loader.firm; do
  [[ -s "$PACKAGE/fat32/$rel" ]] || { echo "Missing required boot file: $rel" >&2; exit 1; }
done
ROOTFS_ARCHIVE="$PACKAGE/rootfs/MiiNora-Debian-Bookworm-armel-rootfs.tar.gz"
MODULES_ARCHIVE="$PACKAGE/modules/3ds-modules.tar"
[[ -s "$ROOTFS_ARCHIVE" ]] || { echo "Missing Debian rootfs archive: $ROOTFS_ARCHIVE" >&2; exit 1; }
[[ -s "$MODULES_ARCHIVE" ]] || { echo "Missing 3DS kernel modules: $MODULES_ARCHIVE" >&2; exit 1; }
# Validate every path in the upstream module archive before extraction.
while IFS= read -r member; do
  case "$member" in /*|../*|*/../*|*/..) echo "Unsafe path in module archive: $member" >&2; exit 1 ;; esac
done < <(tar -tf "$MODULES_ARCHIVE")
# FAT32 cannot represent symlinks. Never overwrite a user's Luma boot.firm.
if find "$PACKAGE/fat32" -type l -print -quit | grep -q .; then
  echo 'The upstream boot package contains symlinks; refusing to copy them to FAT32.' >&2
  exit 1
fi
if find "$PACKAGE/fat32" -type f -name boot.firm -print -quit | grep -q .; then
  echo 'The package unexpectedly contains boot.firm; refusing to overwrite Luma3DS.' >&2
  exit 1
fi
# ext4 has a normal lost+found directory after mkfs; anything else is treated as data.
if find "$ROOT_MOUNT" -mindepth 1 -maxdepth 1 ! -name lost+found -print -quit | grep -q .; then
  echo 'The ext4 target is not empty. Refusing to overwrite it.' >&2
  exit 1
fi

BACKUP="$FAT_MOUNT/MiiNora-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
mapfile -d '' SOURCE_FILES < <(find "$PACKAGE/fat32" -type f -print0)
for src in "${SOURCE_FILES[@]}"; do
  rel="${src#"$PACKAGE/fat32/"}"
  if [[ -e "$FAT_MOUNT/$rel" ]]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -a "$FAT_MOUNT/$rel" "$BACKUP/$rel"
  fi
done

STAGE="$(mktemp -d "$ROOT_MOUNT/.miinora-stage.XXXXXX")"
cleanup_on_exit() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    # The ext4 target was verified empty except lost+found before this run.
    find "$ROOT_MOUNT" -mindepth 1 -maxdepth 1 ! -name lost+found -exec rm -rf -- {} +
    for src in "${SOURCE_FILES[@]}"; do
      rel="${src#"$PACKAGE/fat32/"}"
      rm -f "$FAT_MOUNT/$rel"
      if [[ -e "$BACKUP/$rel" ]]; then
        mkdir -p "$(dirname "$FAT_MOUNT/$rel")"
        cp -a "$BACKUP/$rel" "$FAT_MOUNT/$rel"
      fi
    done
  fi
  rm -rf "$STAGE"
  exit "$rc"
}
trap cleanup_on_exit EXIT

tar --extract --gzip --file "$ROOTFS_ARCHIVE" --directory "$STAGE" \
  --acls --xattrs --same-owner --same-permissions --numeric-owner
tar --extract --file "$MODULES_ARCHIVE" --directory "$STAGE" --same-owner --numeric-owner
MODULE_DIR="$STAGE/lib/modules"
[[ -d "$MODULE_DIR" ]] || { echo '3DS kernel module directory /lib/modules is missing.' >&2; exit 1; }
MODULE_VERSION_DIR="$(find "$MODULE_DIR" -mindepth 1 -maxdepth 1 -type d -print -quit)"
[[ -n "$MODULE_VERSION_DIR" ]] || { echo 'No kernel version directory exists under /lib/modules.' >&2; exit 1; }
find "$MODULE_VERSION_DIR" -type f \( -name '*.ko' -o -name '*.ko.xz' -o -name '*.ko.gz' \) -print -quit | grep -q . || {
  echo 'No 3DS kernel modules were found in the extracted module tree.' >&2; exit 1;
}
command -v depmod >/dev/null || { echo 'kmod/depmod is required on the host (install kmod). ' >&2; exit 1; }
depmod -b "$STAGE" "$(basename "$MODULE_VERSION_DIR")"
test -s "$STAGE/usr/lib/miinora/first-boot-setup.sh"
test -x "$STAGE/bin/sh" || test -x "$STAGE/usr/bin/dash"
if [[ -n "$WIFI_FW" ]]; then
  install -D -m 0644 "$WIFI_FW" "$STAGE/usr/lib/firmware/ath6k/AR6014/hw1.0/fw-ar6014.bin"
else
  install -d "$STAGE/etc/miinora"
  printf 'wifi_firmware=missing\n' > "$STAGE/etc/miinora/hardware-notes.conf"
fi
find "$STAGE" -mindepth 1 -maxdepth 1 -exec mv -t "$ROOT_MOUNT" -- {} +

# Copy the complete upstream FAT32 layout (not only the four checked boot files).
cp -a "$PACKAGE/fat32/." "$FAT_MOUNT/"
printf 'version=%s\nbase=Debian-Bookworm-armel\nboot=3DS-Linux-upstream\n' "$(cat "$PACKAGE/VERSION" 2>/dev/null || echo 0.2.0-alpha)" > "$ROOT_MOUNT/etc/miinora/install.conf"
printf 'MiiNora OS installed.\nBoot payload: luma/payloads/firm_linux_loader.firm\n' > "$FAT_MOUNT/MiiNora-INSTALLED.txt"
sync
trap - EXIT
rm -rf "$STAGE"
echo 'MiiNora system files installed.'
echo 'Keep boot.firm unchanged. Boot using the FIRM Linux Loader payload from Luma3DS.'
if [[ -z "$WIFI_FW" ]]; then echo 'Wi-Fi firmware is not present. Import your own fw-ar6014.bin before Wi-Fi can work.'; fi
