# MiiNora OS

**MiiNora OS 0.2.0-alpha — Debian-based Linux for the original Nintendo 3DS**

MiiNora separates its native 3DS installer from the Linux operating system. The Linux userspace is Debian Bookworm `armel`; the kernel, device tree, ARM9 firmware, matching kernel modules and FIRM Linux Loader come from the dedicated Nintendo 3DS Linux project. Raspberry Pi OS and Raspberry Pi drivers are not used.

## 0.2.0-alpha changes

- New crescent-and-aurora MiiNora emblem, HOME Menu icon and banner.
- Animated startup sequence in the native CIA.
- English first-use installer guide with timezone selection.
- Chunked package download using a bounded 32 KiB RAM buffer and visible progress bar.
- Debian Bookworm armel root filesystem build.
- SysVinit first-boot setup for timezone, hostname, local clock, administrator password and optional normal user.
- OS package builder validates 3DS kernel, DTB, ARM9 firmware, FIRM loader and kernel modules.
- Linux-host installation script validates filesystems and backs up boot assets.

## Read this before installing

This alpha is **not a hardware-verified one-click installer**. The CIA can download the OS package to FAT32. It cannot create an ext4 partition or extract a Debian root filesystem to ext4 using the standard libctru filesystem API. The current safe installation flow therefore needs a Linux host and an already-prepared FAT32 boot partition plus an empty ext4 root partition. See `os/docs/INSTALLATION.md`.

The package uses the actual 3DS-Linux hardware components, not Raspberry Pi drivers. Upstream currently documents top-screen framebuffer, a lower-screen virtual keyboard, SD, battery, Circle Pad, buttons and AR6014 Wi-Fi. Sound is unsupported and shutdown may panic. Wi-Fi requires firmware extracted from the user's own console; that firmware is not redistributed. A fully independent lower-screen touch desktop is not yet proven. See `os/docs/HARDWARE-DRIVER-STATUS.md`.

## Build

Run **Actions → Build MiiNora OS**. CI builds the Debian armel rootfs and packages the upstream 3DS boot assets in one job, builds the CIA/3DSX in another, then publishes a combined prerelease. The workflow checks that `arm-none-eabi-strip` actually exists before packaging; it does not silently publish an incomplete installer.

See `os/README.md`, `os/docs/INSTALLATION.md`, `os/docs/HARDWARE-DRIVER-STATUS.md` and `docs/INSTALLER-SECURITY.md`.

## Build status

See [BUILD-STATUS.md](BUILD-STATUS.md) for what was statically validated and what still requires the native CI toolchain and a real Old 3DS.
