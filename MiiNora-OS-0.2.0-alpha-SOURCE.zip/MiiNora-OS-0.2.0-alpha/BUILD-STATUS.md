# MiiNora 0.2.0-alpha — build status

## Completed in this source update

- Reworked native installer UI in English, including an animated launch sequence, first-use installer preferences, and 0–100% download progress.
- Replaced full-file RAM buffering with bounded 32 KiB download chunks, HTTPS redirect handling, temporary-file writes and preservation of the previous package on download failure.
- Added a minimal Debian Bookworm armel rootfs build script with SysVinit and a one-time first-boot setup guide.
- Added packaging of the upstream Nintendo 3DS boot files and matching kernel modules; the build fails if required boot assets/modules are absent.
- Added a Linux-host installation script that validates the FAT32/ext4 mounts, backs up all incoming boot files, refuses to overwrite a non-empty rootfs, stages extraction and rolls back on failure.
- Generated new MiiNora emblem, 3DS HOME Menu icon, banner and mono startup chime.
- Added CI jobs for Debian rootfs packaging, native CIA/3DSX build and combined prerelease publishing, including an optional manual release-tag input.

## Local checks completed

- C source passed a strict syntax-only check (`-Wall -Wextra -Werror`) against the documented libctru interface prototypes.
- Shell scripts passed `bash -n` / `sh -n`.
- Python asset generator passed `py_compile` and generated the expected 48x48 icon, 256x128 banner and 22.05 kHz mono WAV.
- Workflow YAML parsed and the job dependency graph was checked.

## Not built or hardware-verified in this workspace

- A fresh `.cia` / `.3dsx` was **not** compiled because devkitARM, `arm-none-eabi-strip`, makerom and bannertool are not installed in this execution environment.
- The Debian armel rootfs and combined OS tarball were **not** produced locally because debootstrap and qemu-user-static are unavailable here; the new GitHub Actions workflow is set up to produce them.
- No Old 3DS hardware boot test was run. A syntax check is not a substitute for a native devkitARM build or a console test.
- The full two-screen desktop, general lower-screen touch events, browser and system apps are not implemented in this alpha.
- The current CIA is a package downloader/stager. It cannot create an ext4 partition or extract Debian onto ext4 with the normal libctru SD filesystem API. The documented host-side install step remains required until a separate bootable ext4-capable installer exists.
- AR6014 Wi-Fi requires console-specific firmware extracted by the owner; audio and safe shutdown are upstream limitations.

This source package is therefore a corrected development foundation, **not a ready-to-install stable OS release**. The release workflow must complete, and the result must boot on a real Old 3DS, before it can be described as working MiiNora OS.
