# Old 3DS hardware validation matrix

| Component | Current implementation/source | Status requiring proof |
|---|---|---|
| ARM11 / ARMv6 | Native 3DS CIA installer; Debian armel userspace | Compile and boot test on a real Old 3DS |
| Kernel | Upstream 3DS-Linux `zImage` | Verify exact release starts from FIRM Linux Loader |
| Device tree | Upstream Old-3DS CTR DTB | Verify both LCD devices and SD controller initialize |
| ARM9 helper | Upstream `arm9linuxfw.bin` | Verify FIRM handoff on hardware |
| Kernel modules | Matching upstream `modules.tar`, normalized to `/lib/modules` | Verify `uname -r` and module vermagic match the kernel |
| SD | Upstream 3DS storage support; installer stages package on FAT32 | Repeated read/write, ext4 mount and corruption test |
| Upper display | Upstream 400x240 framebuffer; installer uses console output | Check flicker, orientation and long-run stability |
| Lower display | Upstream virtual keyboard capability | Not a separately verified framebuffer for a full desktop |
| Touch | Installer touch-row navigation | Coordinate accuracy and calibration test on device |
| D-Pad / buttons | Installer navigation; upstream GPIO input | Verify keys on real console |
| Circle Pad | Upstream mouse movement capability | Verify axis range and repeatability |
| Wi-Fi | Upstream Atheros AR6014 kernel driver | Requires owner-extracted `fw-ar6014.bin`; no ready-to-use claim until tested |
| Battery | Upstream battery reporting | Compare values with HOME Menu on hardware |
| Audio | Upstream currently reports unsupported | Not supported in this alpha |
| Power-off | Upstream may panic during shutdown | Do not claim safe power-off until fixed and tested |
| PICA200 | No custom GPU acceleration in this build | No hardware acceleration claim |

A GitHub Actions success is not proof of hardware compatibility. Keep a test record with console model, firmware, kernel version, logs and photos for each real-device test.
