# Installer security and safety notes

- HTTPS certificate validation remains enabled through libctru HTTP services.
- The installer downloads the named OS package release asset, not a mutable source ZIP.
- Downloads use a bounded 32 KiB buffer and write to a `.part` file; incomplete transfers are removed.
- A completed temporary file is renamed into place only after the transfer and file close succeed; an existing package is preserved as a backup until the replacement completes.
- The CIA does not repartition or format the SD card, modify `boot.firm`, or write to NAND.
- The host installer validates FAT32/ext4 mountpoints, refuses to overwrite an existing rootfs, validates module archive paths, stages extraction, and backs up existing boot files.
- SHA-256 sums are generated for OS and release files. The current CIA does not independently verify the detached SHA-256 file; verify `SHA256SUMS` on the Linux host before extraction.
- The console-specific AR6014 Wi-Fi firmware is not redistributed.

The installer is a staging downloader, not yet an on-device ext4 extractor. See `os/docs/INSTALLATION.md` for the safe two-partition process. The installer must not display a successful OS-installation state simply because a package download succeeded.
