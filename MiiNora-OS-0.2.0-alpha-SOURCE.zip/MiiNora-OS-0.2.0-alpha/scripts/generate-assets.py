#!/usr/bin/env python3
"""Generate MiiNora 3DS assets from its emblem source."""
from pathlib import Path
import math, struct, wave
from PIL import Image, ImageDraw, ImageFont, ImageFilter
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "installer/assets"
BRAND = ROOT / "branding/miinora-emblem.png"
ASSETS.mkdir(parents=True, exist_ok=True)
if not BRAND.is_file():
    raise SystemExit(f"Missing branding file: {BRAND}")
src = Image.open(BRAND).convert("RGBA")
pix = src.load(); xs=[]; ys=[]
for y in range(src.height):
    for x in range(src.width):
        r,g,b,a = pix[x,y]
        if a > 8 and max(r,g,b) > 28:
            xs.append(x); ys.append(y)
if not xs: raise SystemExit("Brand image is empty")
emblem = src.crop((min(xs),min(ys),max(xs)+1,max(ys)+1))
side = max(emblem.size)
square = Image.new("RGBA", (side,side), (5,12,24,255))
square.alpha_composite(emblem, ((side-emblem.width)//2,(side-emblem.height)//2))
icon = square.resize((48,48), Image.Resampling.LANCZOS).filter(ImageFilter.UnsharpMask(radius=.7,percent=115,threshold=3))
icon.save(ASSETS/"icon.png", optimize=True)
banner = Image.new("RGBA", (256,128), (5,12,24,255))
d=ImageDraw.Draw(banner)
d.rounded_rectangle((3,3,252,124),radius=12,fill=(8,20,38),outline=(61,194,222),width=2)
banner.alpha_composite(square.resize((96,96),Image.Resampling.LANCZOS),(9,16))
d=ImageDraw.Draw(banner)
try:
    big=ImageFont.truetype("DejaVuSans-Bold.ttf",21); small=ImageFont.truetype("DejaVuSans.ttf",9)
except OSError:
    big=small=ImageFont.load_default()
d.text((110,43),"MiiNora",font=big,fill=(235,247,255))
d.text((112,72),"OS  /  OLD 3DS",font=small,fill=(102,222,235))
d.line((111,91,236,91),fill=(45,176,204),width=2)
banner.convert("RGB").save(ASSETS/"banner.png",quality=95)
rate,seconds=22050,.55
with wave.open(str(ASSETS/"banner.wav"),"wb") as wav:
    wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(rate)
    frames=bytearray()
    for i in range(int(rate*seconds)):
        t=i/rate; fade=min(1.0,t/.025,(seconds-t)/.12)
        sample=int(1800*max(0.0,fade)*(math.sin(2*math.pi*660*t)+.35*math.sin(2*math.pi*990*t)))
        frames += struct.pack("<h",sample)
    wav.writeframes(frames)
print("Generated MiiNora icon, HOME Menu banner and chime.")
