# MiiNora Desktop — implementation boundary

The target is an English lightweight interface: applications on the top display and touch-oriented controls on the lower display. This folder is reserved for the Linux framebuffer shell and window manager.

The currently documented upstream interface provides a top-screen framebuffer and a bottom-screen virtual keyboard. That does not establish a separate lower framebuffer and general touch events for a full desktop. This alpha does not ship a fake desktop binary or claim dual-screen touch window management is ready; the desktop is blocked on implementing and validating those interfaces on real Old 3DS hardware.
