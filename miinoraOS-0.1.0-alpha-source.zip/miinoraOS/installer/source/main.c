#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

#define APP_VERSION "0.1.0-alpha"
#define SOURCE_URL "https://codeload.github.com/sl4m3d/miinoraOS/zip/refs/heads/main"
#define DOWNLOAD_DIR "sdmc:/MiiNora/downloads"
#define DOWNLOAD_FILE DOWNLOAD_DIR "/miinoraOS-main.zip"
#define DOWNLOAD_TEMP DOWNLOAD_DIR "/miinoraOS-main.zip.part"
#define MAX_DOWNLOAD_SIZE (16u * 1024u * 1024u)

typedef enum {
    PAGE_HOME = 0,
    PAGE_BROWSER,
    PAGE_SETTINGS,
    PAGE_ABOUT,
    PAGE_FILES,
    PAGE_DOWNLOAD,
    PAGE_DOWNLOAD_RESULT
} Page;

static PrintConsole *topConsole = NULL;
static PrintConsole *bottomConsole = NULL;
static Page currentPage = PAGE_HOME;
static int selectedItem = 0;
static int downloadResult = 0;
static char statusText[96] = "Ready";
static bool confirmDownloads = true;
static bool showTouchHints = true;
static bool sdReady = false;

static const char *menuItems[] = {
    "Browser (preview)",
    "Settings",
    "About MiiNora",
    "Files",
    "Download repository",
    "Exit installer"
};
#define MENU_COUNT (sizeof(menuItems) / sizeof(menuItems[0]))

static void ensureDownloadDirectory(void)
{
    if (!sdReady) return;
    mkdir("sdmc:/MiiNora", 0777);
    mkdir(DOWNLOAD_DIR, 0777);
}

static void drawFrame(void)
{
    consoleSelect(topConsole);
    consoleClear();
    printf("MiiNora OS  |  %s\n", APP_VERSION);
    printf("OLD 3DS / CTR  |  Installer & system shell\n");
    printf("----------------------------------------\n\n");

    switch (currentPage) {
    case PAGE_HOME:
        printf("MiiNora\n\n");
        printf("A lightweight starting point for the\n");
        printf("MiiNora Linux project.\n\n");
        printf("The CIA is a native 3DS installer app.\n");
        printf("It is not the Debian operating system.\n\n");
        printf("Status: %s\n", statusText);
        break;
    case PAGE_BROWSER:
        printf("MiiNora Browser\n\n");
        printf("Browser shell preview\n\n");
        printf("A full web engine is not included in\n");
        printf("this alpha. Network access is used only\n");
        printf("by the repository download function.\n\n");
        printf("Planned: tabs, bookmarks and downloads.\n");
        break;
    case PAGE_SETTINGS:
        printf("Settings\n\n");
        printf("1. Confirm downloads: %s\n", confirmDownloads ? "ON" : "OFF");
        printf("2. Touch hints:   %s\n", showTouchHints ? "ON" : "OFF");
        printf("\nPress A to toggle the selected setting.\n");
        printf("Use UP/DOWN to select.\n");
        break;
    case PAGE_ABOUT:
        printf("About MiiNora\n\n");
        printf("MiiNora OS %s\n", APP_VERSION);
        printf("Target: Nintendo 3DS Old model (CTR)\n");
        printf("Project: sl4m3d/miinoraOS\n\n");
        printf("Alpha scope: native installer UI and\n");
        printf("repository snapshot downloader.\n\n");
        printf("Debian root filesystem, Linux boot,\n");
        printf("display/touch drivers and apps are not\n");
        printf("yet a verified bootable OS release.\n");
        break;
    case PAGE_FILES: {
        printf("MiiNora Files\n\n");
        printf("SD:/MiiNora/downloads/\n\n");
        if (!sdReady) { printf("SD card filesystem is unavailable.\n"); break; }
        DIR *dir = opendir(DOWNLOAD_DIR);
        if (!dir) {
            printf("Folder is empty or not created.\n");
        } else {
            struct dirent *entry;
            int shown = 0;
            while ((entry = readdir(dir)) != NULL && shown < 12) {
                if (entry->d_name[0] == '.') continue;
                printf("%s\n", entry->d_name);
                shown++;
            }
            if (shown == 0) printf("No files yet.\n");
            closedir(dir);
        }
        break;
    }
    case PAGE_DOWNLOAD:
        printf("Repository download\n\n");
        printf("Source: GitHub main branch\n");
        printf("Destination: SD:/MiiNora/downloads/\n\n");
        printf("The ZIP is saved as miinoraOS-main.zip.\n");
        printf("Existing file will be replaced.\n\n");
        printf("Press A to start or B to cancel.\n");
        break;
    case PAGE_DOWNLOAD_RESULT:
        printf("Download result\n\n");
        printf("%s\n\n", statusText);
        if (downloadResult == 0) {
            printf("Saved to:\n%s\n", DOWNLOAD_FILE);
        }
        printf("Press A or B to return to the menu.\n");
        break;
    }

    consoleSelect(topConsole);
    printf("\n\n----------------------------------------\n");
    printf("B: Back   START: Exit\n");
}

static void drawTouchPanel(void)
{
    consoleSelect(bottomConsole);
    consoleClear();
    printf("MiiNora Control Center\n");
    printf("[ HOME ] [ APPS ] [ SYSTEM ]\n\n");
    if (currentPage == PAGE_HOME) {
        for (int i = 0; i < (int)MENU_COUNT; i++) {
            printf("%c %s\n", selectedItem == i ? '>' : ' ', menuItems[i]);
        }
        if (showTouchHints) printf("\nA: Open   UP/DOWN: Select\n");
    } else if (currentPage == PAGE_SETTINGS) {
        printf("%c Dark interface\n", selectedItem == 0 ? '>' : ' ');
        printf("%c Touch hints\n", selectedItem == 1 ? '>' : ' ');
        if (showTouchHints) printf("\nA: Toggle\n");
    } else if (showTouchHints) {
        printf("Tap the lower screen or use the\n");
        printf("Circle Pad and A/B buttons.\n");
    }
    consoleSelect(bottomConsole);
}

static int downloadRepository(void)
{
    httpcContext context;
    Result result;
    u32 responseCode = 0;
    u32 downloaded = 0;
    u32 contentSize = 0;
    u8 *buffer = NULL;
    FILE *file = NULL;
    int contextOpen = 0;
    int httpcReady = 0;
    int outcome = -1;

    if (!sdReady) {
        snprintf(statusText, sizeof(statusText), "SD card filesystem is unavailable.");
        return -1;
    }

    snprintf(statusText, sizeof(statusText), "Initialising network service...");
    drawFrame();
    result = httpcInit(0);
    if (R_FAILED(result)) {
        snprintf(statusText, sizeof(statusText), "HTTP service unavailable (0x%08lX).", (unsigned long)result);
        return -1;
    }
    httpcReady = 1;

    snprintf(statusText, sizeof(statusText), "Connecting to GitHub...");
    drawFrame();
    result = httpcOpenContext(&context, HTTPC_METHOD_GET, SOURCE_URL, 0);
    if (R_FAILED(result)) {
        snprintf(statusText, sizeof(statusText), "Could not open HTTPS connection (0x%08lX).", (unsigned long)result);
        goto cleanup;
    }
    contextOpen = 1;

    httpcAddRequestHeaderField(&context, "User-Agent", "MiiNora-Installer/0.1.0-alpha");
    httpcAddRequestHeaderField(&context, "Accept", "application/zip");

    /* Keep certificate validation enabled. Add legacy roots exposed by libctru.
       A future GitHub certificate chain may still be newer than the Old 3DS store. */
    httpcAddDefaultCert(&context, SSLC_DefaultRootCert_DigiCert_EV);
    httpcAddDefaultCert(&context, SSLC_DefaultRootCert_USERTrust);
    httpcAddDefaultCert(&context, SSLC_DefaultRootCert_COMODO);
    httpcAddDefaultCert(&context, SSLC_DefaultRootCert_CyberTrust);

    result = httpcBeginRequest(&context);
    if (R_FAILED(result)) {
        snprintf(statusText, sizeof(statusText), "Request failed (0x%08lX).", (unsigned long)result);
        goto cleanup;
    }

    result = httpcGetResponseStatusCodeTimeout(&context, &responseCode, 30000000000ULL);
    if (R_FAILED(result) || responseCode != 200) {
        snprintf(statusText, sizeof(statusText), "GitHub returned HTTP %lu.", (unsigned long)responseCode);
        goto cleanup;
    }

    result = httpcGetDownloadSizeState(&context, &downloaded, &contentSize);
    if (R_FAILED(result) || contentSize == 0 || contentSize > MAX_DOWNLOAD_SIZE) {
        snprintf(statusText, sizeof(statusText), "ZIP size unavailable or above 16 MiB limit.");
        goto cleanup;
    }

    buffer = (u8 *)malloc(contentSize);
    if (!buffer) {
        snprintf(statusText, sizeof(statusText), "Not enough memory for the repository ZIP.");
        goto cleanup;
    }

    snprintf(statusText, sizeof(statusText), "Downloading %lu bytes...", (unsigned long)contentSize);
    drawFrame();
    result = httpcDownloadData(&context, buffer, contentSize, &downloaded);
    if (R_FAILED(result) || downloaded != contentSize) {
        snprintf(statusText, sizeof(statusText), "Download incomplete (0x%08lX).", (unsigned long)result);
        goto cleanup;
    }

    ensureDownloadDirectory();
    file = fopen(DOWNLOAD_TEMP, "wb");
    if (!file) {
        snprintf(statusText, sizeof(statusText), "Could not write to the SD card.");
        goto cleanup;
    }

    size_t written = fwrite(buffer, 1, downloaded, file);
    fclose(file);
    file = NULL;
    if (written != downloaded) {
        remove(DOWNLOAD_TEMP);
        snprintf(statusText, sizeof(statusText), "SD-card write failed.");
        goto cleanup;
    }
    remove(DOWNLOAD_FILE);
    if (rename(DOWNLOAD_TEMP, DOWNLOAD_FILE) != 0) {
        remove(DOWNLOAD_TEMP);
        snprintf(statusText, sizeof(statusText), "Could not finalize the ZIP on the SD card.");
        goto cleanup;
    }

    snprintf(statusText, sizeof(statusText), "Repository snapshot downloaded successfully.");
    outcome = 0;

cleanup:
    if (file) fclose(file);
    if (buffer) free(buffer);
    if (contextOpen) {
        if (outcome != 0) httpcCancelConnection(&context);
        httpcCloseContext(&context);
    }
    if (httpcReady) httpcExit();
    return outcome;
}

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;
    gfxInitDefault();
    topConsole = consoleInit(GFX_TOP, NULL);
    bottomConsole = consoleInit(GFX_BOTTOM, NULL);
    sdReady = R_SUCCEEDED(fsInit());
    if (sdReady) {
        ensureDownloadDirectory();
        struct stat downloadedArchive;
        if (stat(DOWNLOAD_FILE, &downloadedArchive) == 0 && downloadedArchive.st_size > 0) {
            snprintf(statusText, sizeof(statusText), "Source snapshot already exists on SD card.");
        } else {
            currentPage = PAGE_DOWNLOAD;
            downloadResult = downloadRepository();
            currentPage = PAGE_DOWNLOAD_RESULT;
        }
    } else {
        snprintf(statusText, sizeof(statusText), "SD card filesystem unavailable");
    }

    int exitApp = 0;
    while (aptMainLoop() && !exitApp) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        touchPosition touch;
        hidTouchRead(&touch);

        if (kDown & KEY_START) break;

        if (currentPage == PAGE_HOME) {
            if (kDown & KEY_DOWN) selectedItem = (selectedItem + 1) % (int)MENU_COUNT;
            if (kDown & KEY_UP) selectedItem = (selectedItem + (int)MENU_COUNT - 1) % (int)MENU_COUNT;
            if (kDown & KEY_A) {
                switch (selectedItem) {
                case 0: currentPage = PAGE_BROWSER; break;
                case 1: currentPage = PAGE_SETTINGS; selectedItem = 0; break;
                case 2: currentPage = PAGE_ABOUT; break;
                case 3: currentPage = PAGE_FILES; break;
                case 4:
                    if (confirmDownloads) currentPage = PAGE_DOWNLOAD;
                    else { downloadResult = downloadRepository(); currentPage = PAGE_DOWNLOAD_RESULT; }
                    break;
                case 5: exitApp = 1; break;
                }
            }
            if (kDown & KEY_TOUCH) {
                int row = touch.py / 8 - 3;
                if (row >= 0 && row < (int)MENU_COUNT) {
                    selectedItem = row;
                    if (selectedItem < (int)MENU_COUNT) {
                        if (selectedItem == 0) currentPage = PAGE_BROWSER;
                        else if (selectedItem == 1) { currentPage = PAGE_SETTINGS; selectedItem = 0; }
                        else if (selectedItem == 2) currentPage = PAGE_ABOUT;
                        else if (selectedItem == 3) currentPage = PAGE_FILES;
                        else if (selectedItem == 4) {
                            if (confirmDownloads) currentPage = PAGE_DOWNLOAD;
                            else { downloadResult = downloadRepository(); currentPage = PAGE_DOWNLOAD_RESULT; }
                        }
                        else if (selectedItem == 5) exitApp = 1;
                    }
                }
            }
        } else if (currentPage == PAGE_SETTINGS) {
            if (kDown & KEY_DOWN || kDown & KEY_UP) selectedItem = 1 - selectedItem;
            if (kDown & KEY_A) {
                if (selectedItem == 0) confirmDownloads = !confirmDownloads;
                else showTouchHints = !showTouchHints;
            }
            if (kDown & KEY_TOUCH) {
                selectedItem = (touch.py < 120) ? 0 : 1;
                if (selectedItem == 0) confirmDownloads = !confirmDownloads;
                else showTouchHints = !showTouchHints;
            }
        } else if (currentPage == PAGE_DOWNLOAD) {
            if (kDown & KEY_A) {
                downloadResult = downloadRepository();
                currentPage = PAGE_DOWNLOAD_RESULT;
            }
            if (kDown & KEY_TOUCH && touch.py < 120) {
                downloadResult = downloadRepository();
                currentPage = PAGE_DOWNLOAD_RESULT;
            }
        } else if (currentPage == PAGE_DOWNLOAD_RESULT) {
            if (kDown & KEY_A || kDown & KEY_B) currentPage = PAGE_HOME;
        } else if (kDown & KEY_A && currentPage != PAGE_HOME) {
            currentPage = PAGE_HOME;
        }

        if ((kDown & KEY_B) && currentPage != PAGE_HOME) currentPage = PAGE_HOME;

        drawFrame();
        drawTouchPanel();
        gspWaitForVBlank();
        gfxFlushBuffers();
        gfxSwapBuffers();
    }

    if (sdReady) fsExit();
    gfxExit();
    return 0;
}
