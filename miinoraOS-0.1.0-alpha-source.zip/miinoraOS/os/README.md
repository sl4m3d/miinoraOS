# MiiNora Linux base — planned work

This directory is reserved for the Linux distribution work. The target is a minimal Debian armel userspace paired with a kernel/DTB and boot flow proven on the Old 3DS. No bootable image is produced by the current Alpha workflow.

## Required milestones before a Linux image can be called a release

1. Select and pin a known-good 3DS Linux kernel and FIRM Linux Loader revision.
2. Reproduce its Old 3DS boot flow and document the exact SD layout.
3. Build a minimal ARMv6/armel Debian root filesystem and verify its ABI on target hardware.
4. Integrate a display/input stack and independently test the upper and lower screens.
5. Verify WLAN, SD, battery, audio and GPU support individually. Do not infer support from a successful boot.
6. Add recovery and rollback before enabling any automated on-device update.

The first milestone is a reproducible build, not a claim that Debian has already booted on the device.
