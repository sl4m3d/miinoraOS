# Installer safety notes

- The installer downloads one fixed HTTPS URL: the source ZIP for `sl4m3d/miinoraOS` on the `main` branch.
- TLS certificate validation remains enabled; the app does not disable SSL verification.
- The current implementation accepts only a known `Content-Length` up to 32 MiB.
- The ZIP is written to `SD:/MiiNora/downloads/miinoraOS-main.zip`.
- The installer does not extract files, run downloaded code, modify firmware, repartition the card or replace the existing boot configuration.
- Updating or removing the existing 3DS firmware is out of scope for this alpha.
