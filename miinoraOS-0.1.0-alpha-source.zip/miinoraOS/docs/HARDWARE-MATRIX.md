# Old 3DS hardware validation matrix

| Component | Alpha status | Required proof |
|---|---|---|
| ARM11 CPU | native installer target | launch CIA on real Old 3DS |
| Upper LCD | used by installer console | visual test for stable output |
| Lower LCD | used by installer console | visual test and refresh stability |
| Touch | basic menu selection in installer | tap-coordinate and calibration test |
| D-Pad / buttons | basic navigation | verify all used keys |
| Circle Pad | not yet wired as pointer | repeatable axis/range test |
| SD card | installer writes repository ZIP | repeated read/write and corruption test |
| Wi-Fi | installer uses 3DS HTTP service | connect and download real ZIP on target |
| Battery | not exposed in installer | query and compare with HOME Menu |
| PICA200 | no custom GPU acceleration | kernel/driver documentation and visual tests |
| Audio | no app audio dependency | kernel and speaker/headphone test |
| Microphone | not implemented | capture and input test |

A row is not complete merely because the corresponding hardware is present in the console. Attach photos/logs and record the tested model and firmware in each test report.
