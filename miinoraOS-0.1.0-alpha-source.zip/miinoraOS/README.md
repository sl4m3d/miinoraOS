# MiiNora OS

**MiiNora OS 0.1 Alpha — Nintendo 3DS Old model (CTR)**

MiiNora is an experimental Debian-based Linux distribution concept for the original Nintendo 3DS. The current `0.1 Alpha` deliverable is deliberately limited to a native 3DS installer/control-shell CIA and a GitHub source-snapshot downloader. It is **not yet a bootable Debian distribution**.

## What this alpha actually contains

- Native libctru application built for the Old 3DS ARM11 target.
- Top-screen information view and bottom-screen control/menu view.
- About, Settings, Files and Browser-preview screens.
- A repository download action that retrieves the `main` source ZIP over HTTPS and saves it to `SD:/MiiNora/downloads/miinoraOS-main.zip`.
- GitHub Actions workflow that builds the 3DSX and CIA and creates a prerelease on every successful push to `main`.

## Not implemented or hardware-verified yet

- A bootable Debian armel root filesystem for the Old 3DS.
- A MiiNora Linux kernel image and complete device tree/boot configuration.
- A complete driver stack for both displays, touch, Wi-Fi, audio, battery and PICA200 acceleration.
- A full browser engine, window manager, apt package manager or Linux desktop.
- Installation or replacement of the system firmware. This CIA does not flash, repartition or modify the console's firmware.

The current 3DS-Linux work is a separate foundation to investigate and integrate. Old 3DS compatibility and each hardware component must be tested on actual hardware. The CIA itself is a native Home Menu application, not the Linux boot image.

## Build

Push to `main` or run **Actions → Build MiiNora Alpha and publish release**. The workflow installs devkitPro's 3DS toolchain, builds the native app, packages a CIA, generates SHA-256 checksums and creates a prerelease tagged `v0.1.0-alpha.N`.

Required source layout:

- `installer/source/main.c` — native 3DS application.
- `installer/Makefile` — devkitARM/libctru build.
- `scripts/generate-assets.py` — reproducible icon and banner assets.
- `.github/workflows/build-release.yml` — build and release automation.

## Install and use

1. Make a backup of the SD card before installing homebrew CIA files.
2. Install `MiiNora-Installer.cia` with a trusted CIA manager on a console that already has homebrew support.
3. Connect the console to Wi-Fi and launch **MiiNora Installer** from the HOME Menu. On first launch, it automatically attempts to download the source ZIP.
4. The ZIP is saved under `SD:/MiiNora/downloads/miinoraOS-main.zip`. Use **Download repository** in the menu to retry or refresh it.

This installer only downloads the source ZIP. It does not install a Linux kernel or turn the console into Debian.

## Target hardware

- Nintendo 3DS Old model (CTR), ARM11 dual-core SoC.
- Native homebrew toolchain: devkitARM + libctru.
- Target CPU options follow devkitPro's 3DS template (`-march=armv6k -mtune=mpcore`).

## Licensing

The MiiNora source is licensed under the MIT License. Packaging tools are downloaded from their respective upstream releases during CI and are not redistributed in this repository.
