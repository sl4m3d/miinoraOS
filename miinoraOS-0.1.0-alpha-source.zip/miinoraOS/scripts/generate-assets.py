#!/usr/bin/env python3
"""Generate the small 3DS icon and HOME Menu banner used by the installer."""
from pathlib import Path
import wave
import math
import struct
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "installer" / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)

# 48x48 SMDH icon.
im = Image.new("RGBA", (48, 48), (10, 14, 18, 255))
d = ImageDraw.Draw(im)
d.rounded_rectangle((3, 3, 44, 44), radius=9, fill=(18, 30, 38, 255), outline=(255, 180, 84, 255), width=2)
d.rounded_rectangle((9, 9, 39, 25), radius=3, fill=(20, 43, 56, 255), outline=(216, 227, 232, 255), width=1)
d.rounded_rectangle((15, 29, 33, 39), radius=2, fill=(255, 180, 84, 255))
d.line((17, 34, 31, 34), fill=(10, 14, 18, 255), width=2)
im.save(ASSETS / "icon.png")

# 256x128 HOME Menu banner.
banner = Image.new("RGB", (256, 128), (10, 14, 18))
b = ImageDraw.Draw(banner)
b.rectangle((0, 0, 255, 127), outline=(255, 180, 84), width=3)
b.rounded_rectangle((14, 13, 242, 78), radius=8, fill=(17, 35, 47), outline=(56, 80, 93), width=2)
b.rounded_rectangle((26, 22, 230, 64), radius=5, fill=(23, 48, 65), outline=(255, 180, 84), width=1)
b.rectangle((55, 90, 201, 94), fill=(255, 180, 84))
try:
    font = ImageFont.truetype("DejaVuSansMono.ttf", 20)
    small = ImageFont.truetype("DejaVuSansMono.ttf", 9)
except OSError:
    font = ImageFont.load_default()
    small = ImageFont.load_default()
b.text((50, 31), "MiiNora", font=font, fill=(216, 227, 232))
b.text((62, 103), "OLD 3DS  /  ALPHA", font=small, fill=(154, 171, 181))
banner.save(ASSETS / "banner.png")

# Quiet, short stereo PCM cue. The volume is low and no sound API is assumed by the OS.
rate = 22050
seconds = 0.45
with wave.open(str(ASSETS / "banner.wav"), "wb") as wav:
    wav.setnchannels(2)
    wav.setsampwidth(2)
    wav.setframerate(rate)
    frames = bytearray()
    for i in range(int(rate * seconds)):
        t = i / rate
        fade = min(1.0, t / 0.02, (seconds - t) / 0.08)
        sample = int(2200 * max(0.0, fade) * math.sin(2 * math.pi * 660 * t))
        frames += struct.pack("<hh", sample, sample)
    wav.writeframes(frames)
